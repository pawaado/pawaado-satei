const TYPES=['筋力','敏捷','技術','知力','精神'];
const discount={0:0,1:.5,2:.6,3:.7,4:.8,5:.9};
const baseName=n=>n.replace(/[○◎]$/,'');
const hints={}; const owned={};
function costWithHint(s){const lv=Number(hints[baseName(s.name)]||0); const d=discount[lv]||0; const o={}; TYPES.forEach(t=>o[t]=Math.floor((s.cost[t]||0)*(1-d))); return o;}
function sumCost(c){return TYPES.reduce((a,t)=>a+c[t],0)}
function fits(cost, pts){return TYPES.every(t=>(cost[t]||0)<=pts[t])}
function addCost(a,b){const o={}; TYPES.forEach(t=>o[t]=(a[t]||0)+(b[t]||0)); return o}
function subCost(a,b){const o={}; TYPES.forEach(t=>o[t]=(a[t]||0)-(b[t]||0)); return o}
function render(){const tb=document.querySelector('#skillTable tbody'); tb.innerHTML='';
 SKILLS.forEach(s=>{const tr=document.createElement('tr'); if(owned[s.name])tr.classList.add('owned'); if(s.score===null)tr.classList.add('missing-score'); const c=costWithHint(s); const score=s.score===null?'調査中':s.score; tr.innerHTML=`<td>${s.no}</td><td><input type="checkbox" ${owned[s.name]?'checked':''} data-owned="${s.name}"></td><td>${s.name}</td><td>${s.requires||''}</td><td><select class="hintlv" data-base="${baseName(s.name)}">${[0,1,2,3,4,5].map(v=>`<option value="${v}" ${Number(hints[baseName(s.name)]||0)===v?'selected':''}>${v}</option>`).join('')}</select></td>${TYPES.map(t=>`<td>${s.cost[t]}</td>`).join('')}<td class="${s.score<0?'score-neg':''}">${score}</td><td>${sumCost(c)}</td>`; tb.appendChild(tr); });
 document.querySelectorAll('[data-owned]').forEach(el=>el.onchange=e=>{owned[e.target.dataset.owned]=e.target.checked; render();});
 document.querySelectorAll('[data-base]').forEach(el=>el.onchange=e=>{hints[e.target.dataset.base]=Number(e.target.value); render();});}
function points(){return {'筋力':+p0.value||0,'敏捷':+p1.value||0,'技術':+p2.value||0,'知力':+p3.value||0,'精神':+p4.value||0}}
function optimize(){let pts=points(); const selected=[]; const have=new Set(Object.keys(owned).filter(k=>owned[k])); let total=0, used={'筋力':0,'敏捷':0,'技術':0,'知力':0,'精神':0};
 let changed=true; while(changed){changed=false; let best=null;
  for(const s of SKILLS){ if(have.has(s.name)||s.score===null||s.score<=0) continue; let package=[s];
    if(s.requires && !have.has(s.requires)){ const req=SKILLS.find(x=>x.name===s.requires); if(!req||req.score===null) continue; package=[req,s]; }
    const pc=package.reduce((a,x)=>addCost(a,costWithHint(x)),{}); const ps=package.reduce((a,x)=>a+(x.score||0),0); if(!fits(pc,pts)) continue;
    const eff=ps/Math.max(1,sumCost(pc)); if(!best||eff>best.eff) best={package,pc,ps,eff}; }
  if(best){best.package.forEach(x=>{if(!have.has(x.name)){have.add(x.name); selected.push(x); total+=x.score||0;}}); pts=subCost(pts,best.pc); used=addCost(used,best.pc); changed=true; }
 }
 const job=document.getElementById('job').value; document.getElementById('summary').innerHTML=`ジョブ：${job}<br>追加査定：${total}<br>使用経験点：${TYPES.map(t=>`${t}${used[t]||0}`).join(' / ')}<br>残り経験点：${TYPES.map(t=>`${t}${pts[t]||0}`).join(' / ')}`;
 const ol=document.getElementById('result'); ol.innerHTML=''; selected.forEach(s=>{const li=document.createElement('li'); const c=costWithHint(s); li.textContent=`${s.name}（査定 ${s.score} / ${TYPES.map(t=>`${t}${c[t]}`).join('・')}）`; ol.appendChild(li);});
 if(selected.length===0) ol.innerHTML='<li>取得候補なし</li>';
}
document.getElementById('opt').onclick=optimize; document.getElementById('reset').onclick=()=>{Object.keys(hints).forEach(k=>delete hints[k]);Object.keys(owned).forEach(k=>delete owned[k]);render();}; render();